extends Area2D

func _on_body_entered(body):
	if body.is_in_group("enemy"):
		body.take_damage(1)
		print("enemy take damage!")
	else:
		print("Enemy didnt take damage")
