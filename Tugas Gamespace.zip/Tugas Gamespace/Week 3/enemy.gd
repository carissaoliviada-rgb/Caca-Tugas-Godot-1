extends CharacterBody2D

@onready var sprite = $Sprite2D

var health = 3
var speed = 50
var player = null
var is_dead = false

func _ready():
	add_to_group("enemy")
	player = get_tree().get_first_node_in_group("player")
	sprite.play("default")

func _physics_process(delta):
	if is_dead:
		return
	
	# Apply gravity
	if not is_on_floor():
		velocity.y += 500 * delta  # adjust gravity strength if needed
	
	if player:
		var direction_x = sign(player.global_position.x - global_position.x)
		velocity.x = direction_x * speed
	
	move_and_slide()

func take_damage(amount):
	if is_dead:
		return
	
	health -= amount
	
	if health <= 0:
		die()

func die():
	is_dead = true
	velocity = Vector2.ZERO
	
	sprite.play("dead")
	
	# wait until animation finishes, then delete
	await sprite.animation_finished
	queue_free()
